#include<windows.h>
#include <GL/gl.h>
#include <GL/glut.h>
#include <math.h>

void display(void)
{
    /// for moonlight
float theta;
int i;

glColor3ub(13, 13, 13);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+85*cos(theta),550+80*sin(theta));
	}
	glEnd();

glColor3ub(26, 26, 26);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+80*cos(theta),550+80*sin(theta));
	}
	glEnd();

glColor3ub(38, 38, 38);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+75*cos(theta),550+75*sin(theta));
	}
	glEnd();

glColor3ub(51, 51, 51);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+70*cos(theta),550+70*sin(theta));
	}
	glEnd();

glColor3ub(64, 64, 64);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+65*cos(theta),550+65*sin(theta));
	}
	glEnd();


glColor3ub(77, 77, 77);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+60*cos(theta),550+60*sin(theta));
	}
	glEnd();

///for moon
glColor3ub(255, 255, 255);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(750+40*cos(theta),550+40*sin(theta));
	}
	glEnd();
glColor3ub(77, 77, 77);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(770+40*cos(theta),550+40*sin(theta));
	}
	glEnd();

///stars
glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(10+2*cos(theta),450+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(20+2*cos(theta),380+2*sin(theta));
	}
	glEnd();
	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(30+2*cos(theta),340+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(40+2*cos(theta),550+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(50+2*cos(theta),450+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(55+2*cos(theta),440+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(60+2*cos(theta),450+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(65+2*cos(theta),650+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(70+2*cos(theta),500+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(75+2*cos(theta),550+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(80+2*cos(theta),450+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(85+2*cos(theta),580+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(95+2*cos(theta),650+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(100+2*cos(theta),450+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(110+2*cos(theta),630+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(140+2*cos(theta),550+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(232+2*cos(theta),487+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(324+2*cos(theta),476+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(132+2*cos(theta),578+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(234+2*cos(theta),576+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(234+2*cos(theta),454+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(435+2*cos(theta),567+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(533+2*cos(theta),569+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1353+2*cos(theta),450+2*sin(theta));
	}
	glEnd();
	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1234+2*cos(theta),445+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1234+2*cos(theta),546+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1342+2*cos(theta),466+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1143+2*cos(theta),657+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(976+2*cos(theta),567+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(973+2*cos(theta),645+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(864+2*cos(theta),550+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(676+2*cos(theta),577+2*sin(theta));
	}
	glEnd();

	glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(576+2*cos(theta),574+2*sin(theta));
	}
	glEnd();

glColor3ub(191, 191, 191);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(456+2*cos(theta),456+2*sin(theta));
	}
	glEnd();


///backside tree
glColor3ub(0, 15, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(00+40*cos(theta),350+40*sin(theta));
	}
	glEnd();

glColor3ub(0, 16, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(80+40*cos(theta),380+40*sin(theta));
	}
	glEnd();

glColor3ub(0, 17, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(60+50*cos(theta),350+50*sin(theta));
	}
	glEnd();

glColor3ub(0, 18, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(120+30*cos(theta),340+30*sin(theta));
	}
	glEnd();

	glColor3ub(0, 19, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(180+40*cos(theta),350+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 19, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(220+30*cos(theta),380+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 20, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(240+40*cos(theta),360+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 21, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(280+30*cos(theta),340+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 22, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(350+50*cos(theta),330+50*sin(theta));
	}
	glEnd();


	glColor3ub(0, 23, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(370+40*cos(theta),350+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 24, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(400+30*cos(theta),350+75*sin(theta));
	}
	glEnd();

	glColor3ub(0, 25, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(430+30*cos(theta),350+60*sin(theta));
	}
	glEnd();

	glColor3ub(0, 26, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(460+40*cos(theta),340+40*sin(theta));
	}
	glEnd();


	glColor3ub(0, 27, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(500+50*cos(theta),320+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 28, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(540+40*cos(theta),350+30*sin(theta));
	}
	glEnd();

	glColor3ub(0, 29, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(570+30*cos(theta),350+35*sin(theta));
	}
	glEnd();

	glColor3ub(0, 30, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(590+30*cos(theta),380+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 31, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(620+40*cos(theta),360+50*sin(theta));
	}
	glEnd();


	glColor3ub(0, 32, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(650+50*cos(theta),350+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 33, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(690+30*cos(theta),360+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 34, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(730+40*cos(theta),340+70*sin(theta));
	}
	glEnd();


	glColor3ub(0, 35, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(760+50*cos(theta),350+50*sin(theta));
	}
	glEnd();

glColor3ub(0, 34, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(790+40*cos(theta),330+50*sin(theta));
	}
	glEnd();

glColor3ub(0, 33, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(840+40*cos(theta),350+55*sin(theta));
	}
	glEnd();

glColor3ub(0, 32, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(890+50*cos(theta),360+60*sin(theta));
	}
	glEnd();

glColor3ub(0, 31, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(910+30*cos(theta),350+70*sin(theta));
	}
	glEnd();

	glColor3ub(0, 30, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(930+40*cos(theta),340+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 29, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(960+30*cos(theta),370+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 28, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1000+40*cos(theta),360+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 27, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1030+30*cos(theta),380+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 26, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1040+40*cos(theta),360+50*sin(theta));
	}
	glEnd();


	glColor3ub(0, 25, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1050+50*cos(theta),350+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 24, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1080+30*cos(theta),360+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 23, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1100+40*cos(theta),340+70*sin(theta));
	}
	glEnd();


	glColor3ub(0, 22, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1120+50*cos(theta),350+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 21, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1150+50*cos(theta),350+50*sin(theta));
	}
	glEnd();
	glColor3ub(0, 20, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1185+50*cos(theta),350+50*sin(theta));
	}
	glEnd();

	glColor3ub(0, 19, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1200+30*cos(theta),340+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 18, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1220+50*cos(theta),330+50*sin(theta));
	}
	glEnd();


	glColor3ub(0, 17, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1250+40*cos(theta),350+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 16, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1280+30*cos(theta),360+75*sin(theta));
	}
	glEnd();

	glColor3ub(0, 15, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1300+30*cos(theta),350+60*sin(theta));
	}
	glEnd();

	glColor3ub(0, 16, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1340+40*cos(theta),340+40*sin(theta));
	}
	glEnd();


	glColor3ub(0, 15, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1360+50*cos(theta),320+40*sin(theta));
	}
	glEnd();

	glColor3ub(0, 14, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1380+40*cos(theta),350+30*sin(theta));
	}
	glEnd();

	glColor3ub(0, 13, 0);
glBegin(GL_POLYGON);
	for(i=0;i<360;i++)
	{
	  theta=i*3.142/180;
	  glVertex2f(1400+30*cos(theta),350+35*sin(theta));
	}
	glEnd();

///river
glColor3ub (0, 0, 51);
glBegin(GL_POLYGON);
glVertex2d (1400, 25);
glVertex2d (1400, 350);
glVertex2d (00, 350);
glVertex2d (00, 25);
glEnd();

glColor3ub (128, 128, 255);
glBegin(GL_POLYGON);
glVertex2d (550, 348);
glVertex2d (550, 350);
glVertex2d (950, 350);
glVertex2d (950, 348);
glEnd();

glColor3ub (77, 77, 255);
glBegin(GL_POLYGON);
glVertex2d (555, 344);
glVertex2d (555, 346);
glVertex2d (940, 346);
glVertex2d (940, 344);
glEnd();

glColor3ub (70, 70, 255);
glBegin(GL_POLYGON);
glVertex2d (560, 340);
glVertex2d (560, 342);
glVertex2d (935, 342);
glVertex2d (935, 340);
glEnd();

glColor3ub (60, 60, 255);
glBegin(GL_POLYGON);
glVertex2d (565, 336);
glVertex2d (565, 338);
glVertex2d (930, 338);
glVertex2d (930, 336);
glEnd();

glColor3ub (50, 50, 255);
glBegin(GL_POLYGON);
glVertex2d (570, 332);
glVertex2d (570, 334);
glVertex2d (925, 334);
glVertex2d (925, 332);
glEnd();

glColor3ub (40, 40, 255);
glBegin(GL_POLYGON);
glVertex2d (575, 328);
glVertex2d (575, 330);
glVertex2d (920, 330);
glVertex2d (920, 328);
glEnd();

glColor3ub (25, 25, 255);
glBegin(GL_POLYGON);
glVertex2d (580, 324);
glVertex2d (580, 326);
glVertex2d (915, 326);
glVertex2d (915, 324);
glEnd();

glColor3ub (20, 20, 255);
glBegin(GL_POLYGON);
glVertex2d (585, 320);
glVertex2d (585, 322);
glVertex2d (910, 322);
glVertex2d (910, 320);
glEnd();

glColor3ub (10, 10, 255);
glBegin(GL_POLYGON);
glVertex2d (590, 316);
glVertex2d (590, 318);
glVertex2d (905, 318);
glVertex2d (905, 316);
glEnd();

glColor3ub (0, 0, 255);
glBegin(GL_POLYGON);
glVertex2d (595, 312);
glVertex2d (595, 314);
glVertex2d (900, 314);
glVertex2d (900, 312);
glEnd();

glColor3ub (0, 0, 245);
glBegin(GL_POLYGON);
glVertex2d (600, 308);
glVertex2d (600, 310);
glVertex2d (895, 310);
glVertex2d (895, 308);
glEnd();

glColor3ub (0, 0, 235);
glBegin(GL_POLYGON);
glVertex2d (605, 304);
glVertex2d (605, 306);
glVertex2d (890, 306);
glVertex2d (890, 304);
glEnd();

glColor3ub (0, 0, 225);
glBegin(GL_POLYGON);
glVertex2d (610, 300);
glVertex2d (610, 302);
glVertex2d (885, 302);
glVertex2d (885, 300);
glEnd();

glColor3ub (0, 0, 215);
glBegin(GL_POLYGON);
glVertex2d (615, 296);
glVertex2d (615, 298);
glVertex2d (880, 298);
glVertex2d (880, 296);
glEnd();

///yield
glColor3ub (0, 10, 0);
glBegin(GL_POLYGON);
glVertex2d (1400, 25);
glVertex2d (1400, 100);
glVertex2d (00, 100);
glVertex2d (00, 25);
glEnd();

///home

/*home polygn*/
glColor3ub (26, 13, 0);
glBegin(GL_POLYGON);
glVertex2d (100, 25);
glVertex2d (100, 150);
glVertex2d (300, 150);
glVertex2d (300, 25);
glEnd();

/*door polygn*/
glColor3ub (15, 5, 0);
glBegin(GL_POLYGON);
glVertex2d (175, 25);
glVertex2d (175, 125);
glVertex2d (225, 125);
glVertex2d (225, 25);
glEnd();

/*windw polygn*/
glColor3ub (204, 82, 0);
glBegin(GL_POLYGON);
glVertex2d (125, 125);
glVertex2d (125, 100);
glVertex2d (150, 100);
glVertex2d (150, 125);
glEnd();

glColor3ub (255, 102, 0);
glBegin(GL_POLYGON);
glVertex2d (125, 120);
glVertex2d (125, 100);
glVertex2d (150, 100);
glVertex2d (150, 120);
glEnd();

glColor3ub (230, 138, 0);
glBegin(GL_POLYGON);
glVertex2d (125, 115);
glVertex2d (125, 100);
glVertex2d (150, 100);
glVertex2d (150, 115);
glEnd();

glColor3ub (255, 204, 0);
glBegin(GL_POLYGON);
glVertex2d (125, 110);
glVertex2d (125, 100);
glVertex2d (150, 100);
glVertex2d (150, 110);
glEnd();

glColor3ub (204, 82, 0);
glBegin(GL_POLYGON);
glVertex2d (275, 125);
glVertex2d (250, 125);
glVertex2d (250, 100);
glVertex2d (275, 100);
glEnd();

glColor3ub (255, 102, 0);
glBegin(GL_POLYGON);
glVertex2d (275, 120);
glVertex2d (250, 120);
glVertex2d (250, 100);
glVertex2d (275, 100);
glEnd();

glColor3ub (230, 138, 0);
glBegin(GL_POLYGON);
glVertex2d (275, 115);
glVertex2d (250, 115);
glVertex2d (250, 100);
glVertex2d (275, 100);
glEnd();

glColor3ub (255, 204, 0);
glBegin(GL_POLYGON);
glVertex2d (275, 110);
glVertex2d (250, 110);
glVertex2d (250, 100);
glVertex2d (275, 100);
glEnd();


/*roof polygn*/
glColor3ub (51, 26, 0);
glBegin(GL_POLYGON);
glVertex2d (200, 380);
glVertex2d (100, 150);
glVertex2d (300, 150);
glEnd();



glFlush ();
}



void init (void)
{
glClearColor (1.0, 0.0, 1.0,0.0);
glMatrixMode(GL_PROJECTION);
glLoadIdentity();
gluOrtho2D(0, 1400, 0, 680);
}
int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode (GLUT_SINGLE | GLUT_RGB);
glutInitWindowSize (1400, 680);
glutInitWindowPosition (0,0);
glutCreateWindow ("Sarmistha(171-15-9306)");
init ();
glutDisplayFunc(display);
glutMainLoop();
return 0;

}
